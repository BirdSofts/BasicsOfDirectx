configurations =
	{
		resolution = { width = 640 , height = 480 },
		display = { fullscreen = 0 }
	}