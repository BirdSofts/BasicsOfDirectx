# Introduction 
1.	Learning DirectX notes
2.	Game platform development notes

The project is just learning materials, which tries very hard to bring learning instruction, the source code itself and the compilation results all together in coding environment in easy language which results in experiencing more joy while learning DirectX.

<img href="https://github.com/BirdSofts" src="https://github.com/BirdSofts/LearningDirectX/blob/master/ScreenShots/ScreenShot_01.jpg" width="800" height="600" alt="ScreenShot">

<table>
<tr>
<td><b>Creator's Website:</b></td>
<td><a href="https://birdpoems.jimdofree.com/">BirdPoems</a></td>
</tr>
</table>

<table>
<tr>
<td><b>Creator's private repository:</b></td>
<td><a href="https://dev.azure.com/BirdSofts/">BirdSofts</a></td>
<td><b>Creator's public repository:</b></td>
<td><a href="https://github.com/BirdSofts">BirdSofts</a></td>
</tr>
</table>

<table>
<tr>
<td><b>Creator's Emails:</b></td>
<td><a href="mailto:s.mehrdad.47@gamil.com">s.mehrdad.47@gamil.com</a></td>
<td><a href="mailto:s.mehrdad.47@outlook.com">s.mehrdad.47@outlook.com</a></td>
</tr>
</table>

# Getting Started
1.	Installation process:
Compilable! :)

2.	Software dependencies:
<table>
<tr>
<td>Dependent on Windows APIs</td>
</tr>
<tr>
<td>Dependent on Dirext3D, DXGI, DirectXMath, Direct2D and DirectWrite APIs</td>
</tr>
<tr>
<td>Dependent on Lua and Sol script language APIs</td>
</tr>
</table>

3.	Latest releases:
Still no release, just coding and debugging

4.	API references
Windows and DirectX APIs.

# Build and Test
If you are a beginner, use Visual Studio or know what you are doing before doing anything.

Compilable using CMake.
```cmake
cmake --build build-path
```

# Contribute
I appreciate any contribution from anyone, who sees that the project deserves his precious time.

# References
<table>
<tr>
<td><a href="http://www.rastertek.com/">Raster Tek</a></td>
</tr>
<tr>
<td><a href="https://docs.microsoft.com/">Microsoft Docs</a></td>
</tr>
<tr>
<td><a href="https://bell0bytes.eu/">bell0bytes</a></td>
</tr>
<tr>
<td><a href="http://www.cplusplus.com/">cplusplus.com</a></td>
</tr>
<tr>
<td><a href="https://en.cppreference.com/">cppreference.com</a></td>
</tr>
<tr>
<td><a href="https://www.braynzarsoft.net/">Braynzar Soft</a></td>
</tr>
</table>

# Copyright
The literature and all the known and unknown ideas provided within the following learning resource is copyrighted. On the other hand, so far the source code is concerned, most of which is learned and inspired from online references and the addition to them can be used under the licence terms provided with the software itself.